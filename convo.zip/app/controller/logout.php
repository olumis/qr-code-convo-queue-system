<?php

logout();

redirect(u('/'));


